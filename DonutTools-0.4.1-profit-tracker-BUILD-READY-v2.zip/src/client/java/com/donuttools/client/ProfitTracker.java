package com.donuttools.client;

import com.donuttools.DonutTools;

import java.text.NumberFormat;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Chat-only profit tracker.
 *
 * A sale is any chat/game message containing a dollar amount.
 * Examples:
 *   $22k       -> 22,000
 *   $840       -> 840
 *   $1,250.50  -> 1,250.50
 *   $2.5m      -> 2,500,000
 *
 * Messages without "$" are ignored. This is intentional for DonutSMP:
 * "You earned 1 Shard..." is not a sale, while "$22k" is a sale.
 */
public final class ProfitTracker {
    private ProfitTracker() {}

    private static final Pattern MONEY = Pattern.compile(
            "(?i)\\$\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)(?:\\s*([kmb]))?"
    );

    private static boolean running;
    private static long totalCents;
    private static long lastSaleCents;
    private static long sales;
    private static String lastDetectedMessage = "";
    private static String lastIgnoredMessage = "";
    private static String lastMessageKey = "";
    private static long lastMessageAt;
    private static final Deque<Long> history = new ArrayDeque<>();

    public static void start() {
        running = true;
        // ON/OFF is a pause switch. Do not clear existing totals.
        lastMessageKey = "";
        lastMessageAt = 0L;
        lastDetectedMessage = "";
        lastIgnoredMessage = "";
    }

    public static void stop() {
        running = false;
    }

    public static void reset() {
        running = false;
        totalCents = 0L;
        lastSaleCents = 0L;
        sales = 0L;
        lastDetectedMessage = "";
        lastIgnoredMessage = "";
        lastMessageKey = "";
        lastMessageAt = 0L;
        history.clear();
    }

    public static boolean isRunning() {
        return running;
    }

    public static long getSales() {
        return sales;
    }

    public static long getTotalCents() {
        return totalCents;
    }

    public static long getLastSaleCents() {
        return lastSaleCents;
    }

    public static String getLastDetectedMessage() {
        return lastDetectedMessage;
    }

    public static String getLastIgnoredMessage() {
        return lastIgnoredMessage;
    }

    /**
     * Processes both normal chat and game/system messages.
     * Only a "$" money token is required to classify a message as a sale.
     */
    public static boolean processMessage(String raw) {
        if (!running || raw == null || raw.isBlank()) {
            return false;
        }

        String clean = raw.replace('\u00A0', ' ')
                .replaceAll("\\s+", " ")
                .trim();

        if (clean.isEmpty()) {
            return false;
        }

        Matcher money = MONEY.matcher(clean);
        if (!money.find()) {
            lastIgnoredMessage = clean;
            DonutTools.LOGGER.debug("[ProfitTracker] ignored chat/game message (no $): {}", clean);
            return false;
        }

        String number = money.group(1);
        String suffix = money.group(2);

        try {
            double amount = Double.parseDouble(number.replace(",", ""));
            if (suffix != null) {
                switch (suffix.toLowerCase(Locale.ROOT)) {
                    case "k" -> amount *= 1_000.0;
                    case "m" -> amount *= 1_000_000.0;
                    case "b" -> amount *= 1_000_000_000.0;
                    default -> { return false; }
                }
            }

            long cents = Math.round(amount * 100.0);
            if (cents <= 0) {
                return false;
            }

            // The same message can be delivered by both CHAT and GAME.
            // Ignore only an identical line arriving within 1 second.
            String key = clean.toLowerCase(Locale.ROOT);
            long now = System.currentTimeMillis();
            if (key.equals(lastMessageKey) && now - lastMessageAt < 1000L) {
                return false;
            }

            lastMessageKey = key;
            lastMessageAt = now;
            lastDetectedMessage = clean;
            recordSale(cents);
            DonutTools.LOGGER.info("[ProfitTracker] SALE detected: {} -> {} cents", clean, cents);
            return true;
        } catch (NumberFormatException ignored) {
            lastIgnoredMessage = clean;
            return false;
        }
    }

    public static void recordSale(long cents) {
        if (cents <= 0) return;

        lastSaleCents = cents;
        totalCents += cents;
        sales++;

        history.addFirst(cents);
        while (history.size() > 20) {
            history.removeLast();
        }
    }

    public static Deque<Long> history() {
        return new ArrayDeque<>(history);
    }

    public static String money(long cents) {
        return NumberFormat.getNumberInstance(Locale.US)
                .format(cents / 100.0) + " USD";
    }

    public static String compactMoney(long cents) {
        double value = cents / 100.0;
        if (Math.abs(value) >= 1_000_000_000)
            return String.format(Locale.US, "$%.2fB", value / 1_000_000_000);
        if (Math.abs(value) >= 1_000_000)
            return String.format(Locale.US, "$%.2fM", value / 1_000_000);
        if (Math.abs(value) >= 1_000)
            return String.format(Locale.US, "$%.2fK", value / 1_000);
        return String.format(Locale.US, "$%,.2f", value);
    }
}
