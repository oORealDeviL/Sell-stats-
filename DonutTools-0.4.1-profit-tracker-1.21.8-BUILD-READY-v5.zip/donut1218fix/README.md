# Donut Tools 0.4.1

Fabric client mod for Minecraft 1.21.8 / Java 21.

## Two completely separate tools

- `O` → Calculator (independent keybind)
- `P` → Profit Tracker (independent keybind)
- Both can be rebound from Minecraft Controls.

## Calculator

A responsive calculator designed for the small GUI scale commonly used with PojavLauncher:

- keyboard input
- `+ - × ÷`, brackets and percent
- clear, backspace and evaluate
- four editable Quick Actions
- Quick Actions are stored in `.minecraft/config/donuttools-quick-actions.json`
- Quick Actions belong only to the calculator and never interact with Profit Tracker

## Profit Tracker

A separate lightweight chat monitor:

- ON/OFF switch
- RESET
- Total Profit
- Sales count
- Last Sale
- last five detected sale amounts

When switched ON, the tracker only accepts messages received from that moment forward. It does not backfill old chat.

It listens to both Minecraft GAME messages and normal CHAT messages and deduplicates the same line if Minecraft delivers it through both channels.

Examples detected:

- `$840`
- `$22k` → `$22,000`
- `$2.5m` → `$2,500,000`
- `Sold for $840`
- `You earned $2,301.50`

The rule is intentionally simple: **if the received chat/game message contains `$` followed by a number, it is treated as a sale**. Messages without `$` (for example `You earned 1 Shard for playing the server`) are ignored.

## Build

This repository is self-contained. The GitHub Action checks out **this repository**, runs `clean build`, verifies the exact expected JAR, and uploads only that JAR.


## 1.21.8 build fix (v3)
- Canonical Fabric Loom plugin id: `fabric-loom`.
- Fabric Maven is configured in both pluginManagement and dependency repositories.
- CI uses Java 21 and Gradle 8.13.


## 1.21.8 compatibility fix (v5)
- Uses `net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper`.
- Uses the 1.21.8 `KeyMapping(..., String category)` constructor (`key.categories.donuttools.main`).
- Does not use the 1.21.9+ `KeyMapping.Category` API.
- Uses official Mojang mappings, so vanilla classes remain under `net.minecraft.*`.
