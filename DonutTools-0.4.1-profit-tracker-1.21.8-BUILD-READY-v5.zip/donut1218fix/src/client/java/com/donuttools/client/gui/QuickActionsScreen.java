package com.donuttools.client.gui;

import com.donuttools.client.QuickActions;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class QuickActionsScreen extends Screen {
    private final Screen parent;
    private int x, y, w, h;

    public QuickActionsScreen(Screen parent) {
        super(Component.literal("Donut Tools • Quick Actions"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        clearWidgets();
        w = Math.min(820, width - 32);
        h = Math.min(430, height - 32);
        x = (width - w) / 2;
        y = (height - h) / 2;

        for (int i = 0; i < QuickActions.COUNT; i++) {
            int row = i;
            int yy = y + 92 + i * 58;

            EditBox name = new EditBox(font, x + 30, yy, 190, 32, Component.literal("Name"));
            name.setValue(QuickActions.name(i));
            addRenderableWidget(name);

            EditBox expr = new EditBox(font, x + 236, yy, 300, 32, Component.literal("Expression"));
            expr.setValue(QuickActions.expression(i));
            addRenderableWidget(expr);

            addButton(x + 552, yy, 94, 32, "SAVE",
                    b -> QuickActions.set(row, name.getValue(), expr.getValue()));
        }

        addButton(x + w - 104, y + h - 42, 72, 28, "BACK", b -> onClose());
        addButton(x + 30, y + h - 42, 132, 28, "DEFAULTS", b -> {
            QuickActions.resetDefaults();
            minecraft.setScreen(new QuickActionsScreen(parent));
        });
    }

    private void addButton(int x, int y, int w, int h, String label, Button.OnPress action) {
        addRenderableWidget(Button.builder(Component.literal(label), action).bounds(x, y, w, h).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, width, height, 0xFF070A0F);
        g.fill(x, y, x + w, y + h, 0xFF0E141D);
        g.fill(x, y, x + w, y + 3, 0xFF35C7F2);

        g.drawString(font, "DONUT TOOLS", x + 30, y + 20, 0xFFF4F8FC, true);
        g.drawString(font, "QUICK ACTIONS", x + 30, y + 42, 0xFF7E91A5, false);
        g.drawString(font, "NAME", x + 30, y + 75, 0xFF596D82, false);
        g.drawString(font, "EXPRESSION", x + 236, y + 75, 0xFF596D82, false);
        g.drawString(font, "Examples: *0.90   *64   /64   +500",
                x + 30, y + h - 64, 0xFF596D82, false);

        super.render(g, mouseX, mouseY, delta);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) { onClose(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }
}
