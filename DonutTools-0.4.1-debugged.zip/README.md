# Donut Tools 0.4.0

Fabric client mod for Minecraft 26.1.2.

- Minecraft: 26.1.2
- Fabric Loader: 0.19.4
- Fabric API: 0.155.3+26.1.2
- Java: 25
- Fabric Loom: 1.15.5
- Gradle CI: 9.4.1

## Build

The GitHub Actions workflow can build either:
1. a Gradle project already extracted in the repository root, or
2. a ZIP/TAR.GZ archive containing the Gradle project.

The workflow automatically locates `build.gradle` after extraction and uploads the runtime JAR as an artifact.


## Profit Tracker

Profit Tracker reads incoming Minecraft GAME and CHAT messages while it is ON. It does not read inventory contents. It records messages that contain a sale/revenue action and a money amount, for example `Sold for $840` or `You earned $840 from auction`. The UI no longer contains a hard-coded example amount.

The detector also accepts amounts such as `$1,234`, `1,234 USD`, and abbreviated values such as `$2.5k`.
