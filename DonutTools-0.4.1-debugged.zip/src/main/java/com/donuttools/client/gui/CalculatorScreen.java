package com.donuttools.client.gui;

import com.donuttools.client.QuickActions;
import com.donuttools.client.util.CalculatorState;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;

/** Clean, responsive calculator. It intentionally owns nothing from ProfitTracker. */
public final class CalculatorScreen extends Screen {
    private final Screen parent;
    private int x, y, w, h;

    public CalculatorScreen(Screen parent) {
        super(Component.literal("Donut Tools - Calculator"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        clearWidgets();
        w = Math.min(900, width - 20);
        h = Math.min(520, height - 16);
        x = (width - w) / 2;
        y = (height - h) / 2;

        int pad = Math.max(14, Math.min(28, w / 28));
        int displayY = y + 52;
        int displayH = Math.max(58, Math.min(76, h / 6));
        int bodyY = displayY + displayH + 12;
        int gap = 6;
        int keypadW = Math.min(390, (w - pad * 2) / 2);
        int keyW = (keypadW - gap * 3) / 4;
        int keyH = Math.max(24, Math.min(36, (h - bodyY + y - 24) / 6 - gap));

        String[][] keys = {
                {"7", "8", "9", "÷"},
                {"4", "5", "6", "×"},
                {"1", "2", "3", "−"},
                {"0", ".", "(", ")"},
                {"C", "⌫", "%", "+"},
                {"=", "=", "=", "="}
        };
        for (int r = 0; r < keys.length; r++) {
            if (r == keys.length - 1) {
                addButton(x + pad, bodyY + r * (keyH + gap), keypadW, keyH, "=", b -> press("="));
                continue;
            }
            for (int c = 0; c < keys[r].length; c++) {
                String key = keys[r][c];
                addButton(x + pad + c * (keyW + gap), bodyY + r * (keyH + gap),
                        keyW, keyH, key, b -> press(key));
            }
        }

        int actionX = x + pad + keypadW + 18;
        int actionW = w - pad - actionX;
        int actionY = bodyY;
        int actionH = Math.max(26, Math.min(34, keyH));
        int actionGap = 7;
        for (int i = 0; i < QuickActions.COUNT; i++) {
            int index = i;
            int row = i / 2;
            int col = i % 2;
            int bw = Math.max(80, (actionW - actionGap) / 2);
            addButton(actionX + col * (bw + actionGap), actionY + row * (actionH + actionGap),
                    bw, actionH, QuickActions.name(i), b -> QuickActions.apply(index));
        }
        int editY = actionY + 2 * (actionH + actionGap) + 8;
        addButton(actionX, editY, actionW, Math.min(32, actionH + 2), "EDIT QUICK ACTIONS",
                b -> minecraft.setScreen(new QuickActionsScreen(this)));
        addButton(x + w - 30, y + 12, 20, 20, "X", b -> onClose());
    }

    private void press(String key) {
        switch (key) {
            case "C" -> CalculatorState.clear();
            case "⌫" -> CalculatorState.backspace();
            case "=" -> CalculatorState.evaluate();
            case "÷" -> CalculatorState.append("/");
            case "×" -> CalculatorState.append("*");
            case "−" -> CalculatorState.append("-");
            case "%" -> CalculatorState.append("/100");
            default -> CalculatorState.append(key);
        }
    }

    private void addButton(int x, int y, int w, int h, String label, Button.OnPress action) {
        addRenderableWidget(Button.builder(Component.literal(label), action).bounds(x, y, w, h).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        drawBackground(g);
        g.fill(x, y, x + w, y + h, 0xFF0B111A);
        g.fill(x, y, x + w, y + 3, 0xFF20B8FF);

        g.text(font, "DONUT TOOLS", x + 18, y + 12, 0xFFF4F8FC, true);
        g.text(font, "CALCULATOR", x + 18, y + 29, 0xFF6F8298, false);
        g.text(font, "O", x + w - 52, y + 16, 0xFF20B8FF, true);

        int pad = Math.max(14, Math.min(28, w / 28));
        int displayY = y + 52;
        int displayH = Math.max(58, Math.min(76, h / 6));
        int displayW = w - pad * 2;
        g.fill(x + pad, displayY, x + pad + displayW, displayY + displayH, 0xFF111B27);
        g.fill(x + pad, displayY, x + pad + 3, displayY + displayH, 0xFF20B8FF);
        g.text(font, "EXPRESSION", x + pad + 14, displayY + 11, 0xFF71849A, false);
        String expr = CalculatorState.expression.isBlank() ? "0" : CalculatorState.expression;
        String shown = expr.length() > 54 ? expr.substring(expr.length() - 54) : expr;
        g.text(font, shown, x + pad + 14, displayY + 29, 0xFFEAF4FC, true);
        String result = CalculatorState.result;
        g.text(font, result, x + pad + displayW - font.width(result) - 14,
                displayY + displayH - 21, 0xFF20B8FF, true);

        int bodyY = displayY + displayH + 12;
        int keypadW = Math.min(390, (w - pad * 2) / 2);
        g.text(font, "KEYPAD", x + pad, bodyY - 10, 0xFF7B8EA4, false);
        int actionX = x + pad + keypadW + 18;
        g.text(font, "QUICK ACTIONS", actionX, bodyY - 10, 0xFF7B8EA4, false);
        g.fill(actionX - 9, bodyY - 2, actionX - 8, y + h - 14, 0xFF243442);
        g.text(font, "Editable presets", actionX, y + h - 13, 0xFF52667C, false);

        super.extractRenderState(g, mouseX, mouseY, delta);
    }

    private void drawBackground(GuiGraphicsExtractor g) {
        g.fill(0, 0, width, height, 0xFF06090E);
        for (int xx = 0; xx < width; xx += 48) g.fill(xx, 0, xx + 1, height, 0x0AFFFFFF);
        for (int yy = 0; yy < height; yy += 48) g.fill(0, yy, width, yy + 1, 0x0AFFFFFF);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (key == 259) { CalculatorState.backspace(); return true; }
        if (key == 257 || key == 335) { CalculatorState.evaluate(); return true; }
        if (key == 256) { onClose(); return true; }
        return super.keyPressed(event);
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }
}
