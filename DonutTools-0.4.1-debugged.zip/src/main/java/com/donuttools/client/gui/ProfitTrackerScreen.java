package com.donuttools.client.gui;

import com.donuttools.client.ProfitTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Minimal sales monitor. No item/inventory UI; only chat-derived money data. */
public final class ProfitTrackerScreen extends Screen {
    private final Screen parent;
    private int x, y, w, h;

    public ProfitTrackerScreen(Screen parent) {
        super(Component.literal("Donut Tools - Profit Tracker"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        clearWidgets();
        w = Math.min(900, width - 20);
        h = Math.min(460, height - 16);
        x = (width - w) / 2;
        y = (height - h) / 2;

        addButton(x + w - 136, y + 12, 58, 24,
                ProfitTracker.isRunning() ? "ON" : "OFF", b -> {
                    if (ProfitTracker.isRunning()) ProfitTracker.stop();
                    else ProfitTracker.start();
                    rebuildWidgets();
                });
        addButton(x + w - 72, y + 12, 52, 24, "RESET", b -> {
            ProfitTracker.reset();
            rebuildWidgets();
        });
        addButton(x + w - 30, y + 12, 20, 20, "X", b -> onClose());
    }

    private void addButton(int x, int y, int w, int h, String label, Button.OnPress action) {
        addRenderableWidget(Button.builder(Component.literal(label), action).bounds(x, y, w, h).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, width, height, 0xFF06090E);
        for (int xx = 0; xx < width; xx += 48) g.fill(xx, 0, xx + 1, height, 0x0AFFFFFF);
        for (int yy = 0; yy < height; yy += 48) g.fill(0, yy, width, yy + 1, 0x0AFFFFFF);

        g.fill(x, y, x + w, y + h, 0xFF0B111A);
        g.fill(x, y, x + w, y + 3, ProfitTracker.isRunning() ? 0xFF20E6A0 : 0xFFFF5870);

        g.text(font, "DONUT TOOLS", x + 18, y + 12, 0xFFF4F8FC, true);
        g.text(font, "PROFIT TRACKER", x + 18, y + 29, 0xFF6F8298, false);
        g.text(font, "P", x + w - 190, y + 16, 0xFF20E6A0, true);

        int pad = Math.max(14, Math.min(28, w / 28));
        int statusY = y + 58;
        boolean active = ProfitTracker.isRunning();
        int statusColor = active ? 0xFF20E6A0 : 0xFFFF5870;
        g.text(font, active ? "●  LISTENING" : "●  OFF",
                x + pad, statusY, statusColor, true);
        g.text(font, active ? "Watching new chat and game messages for sale amounts."
                : "Turn ON to start counting sales from that moment forward.",
                x + pad, statusY + 18, 0xFF71849A, false);

        int cardY = statusY + 48;
        int gap = 10;
        int cardW = (w - pad * 2 - gap * 2) / 3;
        metric(g, x + pad, cardY, cardW, "TOTAL PROFIT",
                ProfitTracker.compactMoney(ProfitTracker.getTotalCents()), 0xFF20E6A0);
        metric(g, x + pad + cardW + gap, cardY, cardW, "SALES",
                String.valueOf(ProfitTracker.getSales()), 0xFF20B8FF);
        metric(g, x + pad + (cardW + gap) * 2, cardY, cardW, "LAST SALE",
                ProfitTracker.compactMoney(ProfitTracker.getLastSaleCents()), 0xFFB7C7D8);

        int infoY = cardY + 92;
        g.fill(x + pad, infoY, x + w - pad, infoY + 68, 0xFF101A25);
        g.fill(x + pad, infoY, x + pad + 3, infoY + 68, statusColor);
        g.text(font, "CHAT MONITOR", x + pad + 16, infoY + 13, 0xFFF4F8FC, true);
        String detected = ProfitTracker.getLastSaleMessage();
        String monitorText = detected.isBlank()
                ? "No sale detected yet. Waiting for a real chat message..."
                : "Last detected: " + detected;
        if (monitorText.length() > 96) monitorText = monitorText.substring(0, 93) + "...";
        g.text(font, monitorText, x + pad + 16, infoY + 32, 0xFF71849A, false);
        g.text(font, "Only new messages received while ON are counted.",
                x + pad + 16, infoY + 49, 0xFF52667C, false);

        int listY = infoY + 84;
        g.text(font, "RECENT SALES", x + pad, listY, 0xFF7B8EA4, false);
        int rowY = listY + 14;
        int i = 0;
        for (Long cents : ProfitTracker.history()) {
            g.fill(x + pad, rowY, x + w - pad, rowY + 27, 0xFF0F1822);
            g.text(font, "SALE " + (i + 1), x + pad + 12, rowY + 8, 0xFF52667C, false);
            String amount = ProfitTracker.money(cents);
            g.text(font, amount, x + w - pad - font.width(amount) - 12, rowY + 8, 0xFF20E6A0, true);
            rowY += 31;
            if (++i >= 5 || rowY > y + h - 18) break;
        }
        if (i == 0) g.text(font, active ? "Waiting for the next sale message..." : "No sales recorded yet.",
                x + pad, rowY + 4, 0xFF71849A, false);

        super.extractRenderState(g, mouseX, mouseY, delta);
    }

    private void metric(GuiGraphicsExtractor g, int x, int y, int w, String label, String value, int accent) {
        g.fill(x, y, x + w, y + 82, 0xFF101A25);
        g.fill(x, y, x + 3, y + 82, accent);
        g.text(font, label, x + 14, y + 14, 0xFF71849A, false);
        g.text(font, value, x + 14, y + 41, 0xFFEAF4FC, true);
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent event) {
        if (event.key() == 256) { onClose(); return true; }
        return super.keyPressed(event);
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }
}
