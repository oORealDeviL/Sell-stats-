package com.donuttools.client;

import java.text.NumberFormat;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Client-side sale detector. It only reads incoming Minecraft chat/game text. */
public final class ProfitTracker {
    private ProfitTracker() {}

    /*
     * Prefer an explicit currency marker. The second half also accepts a plain
     * number after sale verbs such as "sold ... for 840" or "earned 840".
     */
    private static final Pattern MONEY = Pattern.compile(
            "(?i)(?:\\$\\s*|USD\\s*)([0-9][0-9,]*(?:\\.[0-9]{1,2})?(?:[kmb])?)|"
          + "([0-9][0-9,]*(?:\\.[0-9]{1,2})?)\\s*(?:USD|\\$)|"
          + "(?:\\b(?:for|earned|earn|received|receive|paid|payment|sold|made)\\b\\s*)"
          + "\\$?\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?(?:[kmb])?)");

    /* Deliberately require a sale/revenue action; words like "auction" alone
       must not turn an auction price/balance message into a sale. */
    private static final Pattern SALE_CONTEXT = Pattern.compile(
            "(?i)\\b(?:earned|earn|sold|selling|sell|received|receive|paid|payment|"
          + "you\\s+made|made|sale|sold\\s+for)\\b");

    private static boolean running;
    private static long totalCents;
    private static long lastSaleCents;
    private static long sales;
    private static String lastSaleMessage = "";

    /* Same message can arrive through GAME and CHAT. Keep only a tiny duplicate
       window so two genuine identical sales made later are still counted. */
    private static String lastMessageKey = "";
    private static long lastMessageAt;
    private static final Deque<Long> history = new ArrayDeque<>();

    public static void start() {
        running = true;
        lastMessageKey = "";
        lastMessageAt = 0L;
    }

    public static void stop() { running = false; }

    public static void reset() {
        running = false;
        totalCents = 0L;
        lastSaleCents = 0L;
        sales = 0L;
        lastSaleMessage = "";
        lastMessageKey = "";
        lastMessageAt = 0L;
        history.clear();
    }

    public static boolean isRunning() { return running; }
    public static long getSales() { return sales; }
    public static long getTotalCents() { return totalCents; }
    public static long getLastSaleCents() { return lastSaleCents; }
    public static String getLastSaleMessage() { return lastSaleMessage; }

    /**
     * Process one incoming GAME/CHAT message. Returns true only when a new sale
     * was actually recorded.
     */
    public static boolean processMessage(String raw) {
        if (!running || raw == null || raw.isBlank()) return false;

        String clean = raw.replaceAll("\\s+", " ").trim();
        if (clean.isEmpty() || !SALE_CONTEXT.matcher(clean).find()) return false;

        Matcher money = MONEY.matcher(clean);
        if (!money.find()) return false;

        String number = firstNonBlank(money.group(1), money.group(2), money.group(3));
        if (number == null) return false;

        try {
            long cents = parseMoneyToCents(number);
            if (cents <= 0) return false;

            String key = clean.toLowerCase(Locale.ROOT);
            long now = System.currentTimeMillis();
            if (key.equals(lastMessageKey) && now - lastMessageAt < 750L) return false;
            lastMessageKey = key;
            lastMessageAt = now;

            recordSale(cents, clean);
            return true;
        } catch (NumberFormatException ignored) {
            return false;
        }
    }

    private static String firstNonBlank(String... values) {
        for (String value : values) {
            if (value != null && !value.isBlank()) return value;
        }
        return null;
    }

    private static long parseMoneyToCents(String raw) {
        String value = raw.replace(",", "").trim().toLowerCase(Locale.ROOT);
        double multiplier = 1.0;
        if (value.endsWith("k")) {
            multiplier = 1_000.0;
            value = value.substring(0, value.length() - 1);
        } else if (value.endsWith("m")) {
            multiplier = 1_000_000.0;
            value = value.substring(0, value.length() - 1);
        } else if (value.endsWith("b")) {
            multiplier = 1_000_000_000.0;
            value = value.substring(0, value.length() - 1);
        }
        double amount = Double.parseDouble(value) * multiplier;
        if (!Double.isFinite(amount) || amount <= 0.0 || amount > Long.MAX_VALUE / 100.0) {
            throw new NumberFormatException("Invalid money amount");
        }
        return Math.round(amount * 100.0);
    }

    public static void recordSale(long cents) {
        recordSale(cents, "");
    }

    private static void recordSale(long cents, String message) {
        if (cents <= 0) return;
        lastSaleCents = cents;
        totalCents += cents;
        sales++;
        lastSaleMessage = message == null ? "" : message;
        history.addFirst(cents);
        while (history.size() > 20) history.removeLast();
    }

    public static Deque<Long> history() { return new ArrayDeque<>(history); }

    public static String money(long cents) {
        return NumberFormat.getNumberInstance(Locale.US).format(cents / 100.0) + " USD";
    }

    public static String compactMoney(long cents) {
        double value = cents / 100.0;
        if (Math.abs(value) >= 1_000_000_000) return String.format(Locale.US, "$%.2fB", value / 1_000_000_000);
        if (Math.abs(value) >= 1_000_000) return String.format(Locale.US, "$%.2fM", value / 1_000_000);
        if (Math.abs(value) >= 1_000) return String.format(Locale.US, "$%.2fK", value / 1_000);
        return String.format(Locale.US, "$%,.2f", value);
    }
}
