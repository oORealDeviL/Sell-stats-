# Donut Tools 0.4.0

Fabric client mod for Minecraft 26.1.2 / Java 25.

## Two completely separate tools

- `O` → Calculator (independent keybind)
- `P` → Profit Tracker (independent keybind)
- Both can be rebound from Minecraft Controls.

## Calculator

A responsive calculator designed for the small GUI scale commonly used with PojavLauncher:

- keyboard input
- `+ - × ÷`, brackets and percent
- clear, backspace and evaluate
- four editable Quick Actions
- Quick Actions are stored in `.minecraft/config/donuttools-quick-actions.json`
- Quick Actions belong only to the calculator and never interact with Profit Tracker

## Profit Tracker

A separate lightweight chat monitor:

- ON/OFF switch
- RESET
- Total Profit
- Sales count
- Last Sale
- last five detected sale amounts

When switched ON, the tracker only accepts messages received from that moment forward. It does not backfill old chat.

It listens to both Minecraft GAME messages and normal CHAT messages and deduplicates the same line if Minecraft delivers it through both channels.

Examples detected:

- `You earned $840 from auction`
- `You earned $2,301.50 from auction`
- `Sold for $840`
- `Sale: $840`
- `Received $840`

Balance/price messages without sale/revenue wording are intentionally ignored.

## Build

This repository is self-contained. The GitHub Action checks out **this repository**, runs `clean build`, verifies the exact expected JAR, and uploads only that JAR.
