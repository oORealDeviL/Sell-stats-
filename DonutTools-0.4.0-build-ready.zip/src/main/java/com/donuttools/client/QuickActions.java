package com.donuttools.client;

import com.donuttools.client.util.CalculatorState;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

public final class QuickActions {
    private QuickActions() {}

    public static final int COUNT = 4;
    private static final String[] DEFAULT_NAMES = {"AFTER TAX", "×64", "÷64", "×2"};
    private static final String[] DEFAULT_EXPRESSIONS = {"*0.90", "*64", "/64", "*2"};

    private static final String[] names = Arrays.copyOf(DEFAULT_NAMES, COUNT);
    private static final String[] expressions = Arrays.copyOf(DEFAULT_EXPRESSIONS, COUNT);

    private static Path file() {
        return net.fabricmc.loader.api.FabricLoader.getInstance()
                .getConfigDir().resolve("donuttools-quick-actions.json");
    }

    public static void load() {
        Path path = file();
        if (!Files.exists(path)) return;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(path)).getAsJsonObject();
            JsonArray actions = root.getAsJsonArray("actions");
            if (actions == null) return;
            for (int i = 0; i < COUNT && i < actions.size(); i++) {
                JsonObject a = actions.get(i).getAsJsonObject();
                if (a.has("name")) names[i] = a.get("name").getAsString();
                if (a.has("expression")) expressions[i] = a.get("expression").getAsString();
            }
        } catch (Exception ignored) {}
    }

    public static void save() {
        JsonObject root = new JsonObject();
        JsonArray actions = new JsonArray();
        for (int i = 0; i < COUNT; i++) {
            JsonObject a = new JsonObject();
            a.addProperty("name", names[i]);
            a.addProperty("expression", expressions[i]);
            actions.add(a);
        }
        root.add("actions", actions);
        try {
            Files.writeString(file(), root.toString());
        } catch (IOException ignored) {}
    }

    public static String name(int i) { return names[i]; }
    public static String expression(int i) { return expressions[i]; }

    public static void set(int i, String name, String expression) {
        if (i < 0 || i >= COUNT) return;
        names[i] = (name == null || name.isBlank()) ? "ACTION " + (i + 1) : name.trim();
        expressions[i] = expression == null ? "" : expression.trim();
        save();
    }

    public static void apply(int i) {
        if (i < 0 || i >= COUNT) return;
        String expr = expressions[i];
        if (expr.isBlank()) return;
        CalculatorState.append(expr);
        CalculatorState.evaluate();
    }

    public static void resetDefaults() {
        System.arraycopy(DEFAULT_NAMES, 0, names, 0, COUNT);
        System.arraycopy(DEFAULT_EXPRESSIONS, 0, expressions, 0, COUNT);
        save();
    }
}
