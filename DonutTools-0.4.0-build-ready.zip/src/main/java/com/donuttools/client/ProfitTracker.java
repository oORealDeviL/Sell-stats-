package com.donuttools.client;

import java.text.NumberFormat;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Chat-only sale detector. It never reads inventory or item data. */
public final class ProfitTracker {
    private ProfitTracker() {}

    private static final Pattern MONEY = Pattern.compile(
            "(?i)(?:\\$\\s*|USD\\s*)([0-9][0-9,]*(?:\\.[0-9]{1,2})?)|"
          + "([0-9][0-9,]*(?:\\.[0-9]{1,2})?)\\s*(?:USD|\\$)");

    // Positive sale/revenue language. Kept deliberately narrow to avoid counting balance/price lines.
    private static final Pattern SALE_CONTEXT = Pattern.compile(
            "(?i)\\b(earned|earn|sold|sale|sales|received|receive|revenue|"
          + "auction|selling|sell|payment|paid|you\\s+made|made)\\b");

    private static boolean running;
    private static long totalCents;
    private static long lastSaleCents;
    private static long sales;
    private static String lastMessageKey = "";
    private static long lastMessageAt;
    private static final Deque<Long> history = new ArrayDeque<>();

    public static void start() {
        running = true;
        // Do not clear previous totals. ON/OFF is a pause switch.
        // Messages received before this call can never be processed because running was false.
        lastMessageKey = "";
        lastMessageAt = 0L;
    }

    public static void stop() { running = false; }

    public static void reset() {
        running = false;
        totalCents = 0L;
        lastSaleCents = 0L;
        sales = 0L;
        lastMessageKey = "";
        lastMessageAt = 0L;
        history.clear();
    }

    public static boolean isRunning() { return running; }
    public static long getSales() { return sales; }
    public static long getTotalCents() { return totalCents; }
    public static long getLastSaleCents() { return lastSaleCents; }

    public static boolean processMessage(String raw) {
        if (!running || raw == null || raw.isBlank()) return false;

        String clean = raw.replaceAll("\\s+", " ").trim();
        if (clean.isEmpty() || !SALE_CONTEXT.matcher(clean).find()) return false;

        Matcher money = MONEY.matcher(clean);
        if (!money.find()) return false;

        String number = money.group(1) != null ? money.group(1) : money.group(2);
        try {
            double amount = Double.parseDouble(number.replace(",", ""));
            long cents = Math.round(amount * 100.0);
            if (cents <= 0) return false;

            // CHAT + GAME can deliver the same line. Ignore an identical line arriving within 1 second.
            String key = clean.toLowerCase(Locale.ROOT);
            long now = System.currentTimeMillis();
            if (key.equals(lastMessageKey) && now - lastMessageAt < 1000L) return false;
            lastMessageKey = key;
            lastMessageAt = now;

            recordSale(cents);
            return true;
        } catch (NumberFormatException ignored) {
            return false;
        }
    }

    public static void recordSale(long cents) {
        if (cents <= 0) return;
        lastSaleCents = cents;
        totalCents += cents;
        sales++;
        history.addFirst(cents);
        while (history.size() > 20) history.removeLast();
    }

    public static Deque<Long> history() { return new ArrayDeque<>(history); }

    public static String money(long cents) {
        return NumberFormat.getNumberInstance(Locale.US).format(cents / 100.0) + " USD";
    }

    public static String compactMoney(long cents) {
        double value = cents / 100.0;
        if (Math.abs(value) >= 1_000_000_000) return String.format(Locale.US, "$%.2fB", value / 1_000_000_000);
        if (Math.abs(value) >= 1_000_000) return String.format(Locale.US, "$%.2fM", value / 1_000_000);
        if (Math.abs(value) >= 1_000) return String.format(Locale.US, "$%.2fK", value / 1_000);
        return String.format(Locale.US, "$%,.2f", value);
    }
}
