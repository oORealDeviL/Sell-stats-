# Donut Tools 0.4.0

Fabric client mod for Minecraft 26.1.2.

- Minecraft: 26.1.2
- Fabric Loader: 0.19.4
- Fabric API: 0.155.3+26.1.2
- Java: 25
- Fabric Loom: 1.15.5
- Gradle CI: 9.4.1

## Build

The GitHub Actions workflow can build either:
1. a Gradle project already extracted in the repository root, or
2. a ZIP/TAR.GZ archive containing the Gradle project.

The workflow automatically locates `build.gradle` after extraction and uploads the runtime JAR as an artifact.
